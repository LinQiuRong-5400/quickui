/*
 * @Author: edwin
 * @Date: 2024-04-11 20:18:21
 * @LastEditors: edwin
 * @LastEditTime: 2024-04-17 19:37:50
 */
'use strict';
const { dialog } = require('electron');
const fs = require('fs');
const path = require('path');

var _generating = false;

module.exports = {
  load () {
  },

  unload () {
  },

  startGenerate(data) {
    Editor.log("项目路径: " + Editor.Project.path);
    let selectFile = data.selectFile;
    let selectDirectory = data.selectDirectory;
    let input = JSON.parse(fs.readFileSync(selectFile, 'utf-8'));
    if (input && input.tree && input.tree.length > 0) {
      Editor.log("成功读取JSON: " + selectFile);
      let imageSrc = path.dirname(selectFile);
      try {
        this.imageImport(input.tree, imageSrc, selectDirectory, data.selectDirectoryCut);
      } catch (error) {
        Editor.error(error);
      }
    } else {
      Editor.error("JSON文件不合法! " + selectFile);
    }
  },

  imageImport(tree, src, dst, dstCut) {
    Editor.log("源目录: " + src + " " + "目标目录: " + dst);
    let dstDB = "db://" + dst.replace(Editor.Project.path + "\\", "").replace(/\\/g, "/");
    let files = [];
    if (!fs.existsSync(dst) && fs.statSync(dst).isDirectory()) {
      Editor.log("创建目录: " + dst);
      fs.mkdirSync(dst);
    }
    Editor.assetdb.refresh(dstDB);
    tree.forEach(node => {
      Editor.Ipc.sendToPanel('quickui', 'quickui:onChangeProgress', {
        name: "导入图片: " + node.name,
        value: 0.2
      });
      let srcPath = path.join(src, node.name + ".png");
      if (fs.existsSync(srcPath)) {
        files.push(srcPath);
      } else {
        Editor.error("指定的文件路径不存在: " + srcPath);
      }
    });
    Editor.assetdb.import(files, dstDB, function (err, results) {
      results.forEach(function (result) {
        // result.uuid
        // result.parentUuid
        // result.url
        // result.path
        // result.type
        Editor.log("图片已成功导入到: " + result.path);
      });
      Editor.Scene.callSceneScript('quickui', 'generatePrefab', {tree: tree, dst: dst, dstCut: dstCut}, function (err, msg) {
        Editor.log(msg);
        _generating = false;
      });
    });
  },

  messages: {
    'open' () {
      Editor.Panel.open('quickui');
    },
    'openDialog' (event, data) {
      if (data) {
        let paths = dialog.showOpenDialog(data);
        Editor.Ipc.sendToPanel('quickui', 'quickui:onDialogEnd', {
          type: data.properties[0],
          paths: paths
        });
      }
    },
    'startGenerate' (event, data) {
      if (_generating) {
        return;
      }
      _generating = true;
      this.startGenerate(data);
    },
  },
};