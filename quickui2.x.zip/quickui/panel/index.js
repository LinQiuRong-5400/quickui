/*
 * @Author: edwin
 * @Date: 2024-04-11 20:18:21
 * @LastEditors: edwin
 * @LastEditTime: 2024-04-15 10:07:36
 */
const fs = require('fs');

var defaultFilePath = "";
var defaultDirPath = Editor.Project.path + "\\assets\\resources";
var selectFile = "";
var selectDirectory = "";

Editor.Panel.extend({
  style: fs.readFileSync(Editor.url('packages://quickui/panel/index.css', 'utf8')),
  template: fs.readFileSync(Editor.url('packages://quickui/panel/index.html', 'utf8')),

  $: {
    selectPaths: "#selectPaths",
    btnSelectFile: '#btnSelectFile',
    btnSelectDirectory: '#btnSelectDirectory',
    btnGenerate: '#btnGenerate',
    progressName: '#progressName',
    progress: '#progress'
  },

  ready () {
    this.updatePaths();
    this.$btnSelectFile.addEventListener('confirm', () => {
      Editor.Ipc.sendToMain('quickui:openDialog', {
        properties: ['openFile'],
        title: "选择JSON文件",
        defaultPath: selectFile.length > 0 ? selectFile : defaultFilePath,
        filters: [
          {name: 'JSON文件', extensions: ['json']}
        ]
      });
    });
    this.$btnSelectDirectory.addEventListener('confirm', () => {
      Editor.Ipc.sendToMain('quickui:openDialog', {
        properties: ['openDirectory'],
        title: "选择项目中的目录",
        defaultPath: selectDirectory.length > 0 ? selectDirectory : defaultDirPath
      });
    });
    this.$btnGenerate.addEventListener('confirm', () => {
      if (this.checkCanGenerate()) {
        Editor.Ipc.sendToMain('quickui:startGenerate', {
          selectFile: selectFile,
          selectDirectory: selectDirectory,
          selectDirectoryCut: selectDirectory.replace(defaultDirPath+'\\', "")
        });
      }
    });
  },

  messages: {
    'quickui:onDialogEnd' (event, data) {
      if (data.paths && data.paths.length > 0) {
        if (data.type == "openFile") {
          selectFile = data.paths[0];
          Editor.log(selectFile);
          this.updatePaths();
        } else if (data.type == 'openDirectory') {
          selectDirectory = data.paths[0];
          Editor.log(selectDirectory);
          this.updatePaths();
        }
      }
    },

    'quickui:onChangeProgress' (event, data) {
      let progressVal = data.value * 100
      this.$progressName.textContent = "进度: " + progressVal + "% " + data.name;
      this.$progress.value = progressVal;
    }
  },

  updatePaths() {
    this.$selectPaths.value = "选择JSON: " + selectFile + "\n" + "选择目录: " + selectDirectory;
    let canGen = selectFile.length > 0 && selectDirectory.length > 0;
    this.$btnGenerate.style.display = canGen ? "block" : "none";
  },

  checkCanGenerate() {
    let canGen = true;
    if (!selectDirectory.includes(defaultDirPath)) {
        canGen = false;
        Editor.log("目标目录不在resources中: " + selectDirectory);
        Editor.log("项目资源路径: " + defaultDirPath);
    }
    return canGen;
  }
});