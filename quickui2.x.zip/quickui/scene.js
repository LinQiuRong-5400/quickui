/*
 * @Author: edwin
 * @Date: 2024-04-12 18:58:25
 * @LastEditors: edwin
 * @LastEditTime: 2024-04-15 15:33:57
 */
const path = require('path');
const fs = require('fs');

var _root = null;
var _data = null;
var _event = null;
var _curNum = 0;
var _totalNum = 0;

module.exports = {
    _exportPrefab() {
        if (cc.isValid(_root) && _data != null) {
            let imageDst = _data.dst;
            let dirName = path.basename(imageDst);
            // this._traverseNode(_root, "");
            let prefabPath = path.join(imageDst, dirName + ".prefab").replace(/\\/g, "/");
            this._savePrefab(prefabPath, _root);
            if (_event && _event.reply) {
                _event.reply(null, "执行完毕");
            }
            _root.destroy();
            _data = null;
            _event = null;
        }
    },
    
    _savePrefab(prefabPath, root) {
        let prefab = new cc.Prefab();
        prefab.data = root;
        prefab.nativeUrl = prefabPath;
        let str = prefab.serialize();
        if (fs.existsSync(prefabPath)) {
            fs.unlinkSync(prefabPath);
        }
        try {
            fs.writeFileSync(prefabPath, str, {flag: "a"});
            Editor.log("保存预制成功: " + prefabPath);
            Editor.Ipc.sendToPanel('quickui', 'quickui:onChangeProgress', {
                name: "保存预制成功: " + prefabPath,
                value: 1
            });
            let refreshPath = "db://" + _data.dst.replace(Editor.Project.path + "\\", "").replace(/\\/g, "/") + "/" + path.basename(prefabPath);
            Editor.log("刷新地址: " + refreshPath);
            Editor.assetdb.refresh(refreshPath);
            Editor.Ipc.sendToPanel('quickui', 'quickui:onChangeProgress', {
                name: "刷新地址: " + refreshPath,
                value: 1
            });
        } catch (error) {
            Editor.error(error);
        }
        prefab.destroy();
        prefab = null;
    },

    _traverseNode(node, prefix) {
        if (cc.isValid(node)) {
            let sprite = node.getComponent(cc.Sprite);
            Editor.log(prefix + node.name + " sprite: " + (sprite != null ? sprite.name : "null"));
        }
        let childs = node.children;
        childs.forEach(subNode => {
            this._traverseNode(subNode, (prefix+"-"));
        });
    },

    _createSprite(node, dir) {
        let imageObject = new cc.Node(node.name);
        imageObject.x = node.x;
        imageObject.y = node.y;
        imageObject.width = node.width;
        imageObject.height = node.height;
        let relativePath = dir + "/" + node.name;
        Editor.Ipc.sendToPanel('quickui', 'quickui:onChangeProgress', {
            name: "加载Sprite: " + node.name,
            value: 0.5
        });
        cc.resources.load(relativePath, cc.SpriteFrame, (err, spriteFrame) => {
            Editor.Ipc.sendToPanel('quickui', 'quickui:onChangeProgress', {
                name: "加载Sprite: " + spriteFrame.name + (err ? "失败": "成功") ,
                value: 0.6
            });
            _curNum++;
            let isLast = _curNum >= _totalNum;
            if (err) {
                Editor.error("加载精灵帧失败:", err);
            } else {
                let sprite = imageObject.addComponent(cc.Sprite);
                sprite.spriteFrame = spriteFrame;
                Editor.log("设置图片为Sprite: " + relativePath);
            }
            if (isLast) {
                this._exportPrefab();
            }
        });
        return imageObject;
    },

    'generatePrefab': function (event, data) {
        let tree = data.tree
        let imageDst = data.dstCut;
        let dirname = path.basename(imageDst);
        let loadedMap = new Map();
        _root = new cc.Node(dirname);
        _root.width = 1280;
        _root.height = 720;
        _data = data;
        _event = event;
        _curNum = 0;
        _totalNum = tree.length;
        tree.forEach(node => {
            let parentId = node.parentId;
            let gameObject = this._createSprite(node, imageDst);
            if (gameObject != null) {
                if (parentId >= 0 && loadedMap.get(parentId)) {
                    gameObject.setParent(loadedMap.get(parentId));
                    gameObject.position = loadedMap.get(parentId).convertToNodeSpaceAR(gameObject.position); // photoshop导出的坐标为世界坐标
                } else {
                    gameObject.setParent(_root);
                }
                if (!loadedMap.get(node.id)) {
                    loadedMap.set(node.id, gameObject);
                }
            }
        });
    }
};