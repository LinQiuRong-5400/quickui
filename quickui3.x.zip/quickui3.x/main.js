/*
 * @Author: edwin
 * @Date: 2024-04-11 20:18:21
 * @LastEditors: edwin
 * @LastEditTime: 2024-07-02 11:14:05
 */
'use strict';
const { dialog } = require('electron');
const fs = require('fs');
const path = require('path');

var _generating = false;

module.exports = {
  load () {
  },

  unload () {
  },

  startGenerate(data) {
    console.log("项目路径: " + Editor.Project.path);
    let selectFile = data.selectFile;
    let selectDirectory = data.selectDirectory;
    let input = JSON.parse(fs.readFileSync(selectFile, 'utf-8'));
    if (input && input.tree && input.tree.length > 0) {
      console.log("成功读取JSON: " + selectFile);
      let imageSrc = path.dirname(selectFile);
      try {
        this.imageImport(input.tree, imageSrc, selectDirectory, data.selectDirectoryCut);
      } catch (error) {
        console.error(error);
      }
    } else {
      console.error("JSON文件不合法! " + selectFile);
    }
  },

  imageImport(tree, src, dst, dstCut) {
    console.log("源目录: " + src + " " + "目标目录: " + dst);
    let dstDB = "db://" + dst.replace(Editor.Project.path + "\\", "").replace(/\\/g, "/");
    let files = [];
    if (!fs.existsSync(dst) && fs.statSync(dst).isDirectory()) {
      console.log("创建目录: " + dst);
      fs.mkdirSync(dst);
    }
    // Editor.Message.request("asset-db", 'refresh-asset', dstDB);
    tree.forEach(node => {
      Editor.Message.send("quickui", "onChangeProgress", {
        name: "导入图片: " + node.name,
        value: 0.2
      });
      let srcPath = path.join(src, node.name + ".png");
      if (fs.existsSync(srcPath)) {
        files.push(srcPath);
      } else {
        console.error("指定的文件路径不存在: " + srcPath);
      }
    });
    let spMap = {};
    let importEnd = function (files) {
      _generating = false;
      if (files.length == 0) {
        console.log("导入完成");
        Editor.Message.request("scene", 'execute-scene-script', {
          name: "quickui",
          method: "generatePrefab",
          args: [{tree: tree, dst: dst, dstCut: dstCut, spMap: spMap}]
        });
      }
    }
    for (let i = 0; i < files.length; i++) {
      let targetPath = dstDB + "/" + path.basename(files[i]);
      let realPath = dst + "\\" + path.basename(files[i]);
      if (fs.existsSync(realPath)) {
        fs.unlinkSync(realPath);
        //Editor.Message.request('asset-db', 'refresh-asset', targetPath);
      }
      Editor.Message.request('asset-db', 'import-asset', files[i], targetPath, {
        overwrite: true
      }).then((result) => {
        if (result) {
          for (const key in result.subAssets) {
            if (Object.hasOwnProperty.call(result.subAssets, key)) {
              const element = result.subAssets[key];
              if (element.type == "cc.SpriteFrame") {
                spMap[element.displayName] = element;
              }
            }
          }
          console.log("图片已成功导入到: " + result.path);
        }
        files.pop();
        importEnd(files);
      }).catch((err) => {
        console.log("导入图片失败: " + err);
        files.pop();
        importEnd(files);
      });
    }
  },

  methods: {
    'open'() {
      Editor.Panel.open('quickui');
    },
    "openDialog"(data) {
      if (data) {
        dialog.showOpenDialog(data).then(result => {
          if (!result.canceled) {
            Editor.Message.send("quickui", "onDialogEnd", {
              type: data.properties[0],
              paths: result.filePaths
            });
          }
        });
      }
    },
    "startGenerate"(data) {
      if (_generating) {
        return;
      }
      _generating = true;
      this.module.startGenerate(data);
    },
  },
};