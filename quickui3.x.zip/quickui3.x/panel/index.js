/*
 * @Author: edwin
 * @Date: 2024-04-11 20:18:21
 * @LastEditors: edwin
 * @LastEditTime: 2024-07-02 10:27:42
 */
const fs = require('fs');
const path = require('path');

var defaultFilePath = "";
var defaultDirPath = Editor.Project.path + "\\assets\\resources";
var selectFile = "";
var selectDirectory = "";

module.exports = Editor.Panel.define({
  style: fs.readFileSync(path.join(__dirname, "../panel/index.css"), "utf-8"),
  template: fs.readFileSync(path.join(__dirname, "../panel/index.html"), "utf-8"),

  $: {
    selectPaths: "#selectPaths",
    btnSelectFile: '#btnSelectFile',
    btnSelectDirectory: '#btnSelectDirectory',
    btnGenerate: '#btnGenerate',
    progressName: '#progressName',
    progress: '#progress'
  },

  ready() {
    this.updatePaths();
    this.$.btnSelectFile.addEventListener('confirm', () => {
      Editor.Message.send("quickui", "openDialog", {
        properties: ['openFile'],
        title: "选择JSON文件",
        defaultPath: selectFile.length > 0 ? selectFile : defaultFilePath,
        filters: [
          {name: 'JSON文件', extensions: ['json']}
        ]
      });
    });
    this.$.btnSelectDirectory.addEventListener('confirm', () => {
      Editor.Message.send("quickui", "openDialog", {
        properties: ['openDirectory'],
        title: "选择项目中的目录",
        defaultPath: selectDirectory.length > 0 ? selectDirectory : defaultDirPath
      });
    });
    this.$.btnGenerate.addEventListener('confirm', () => {
      if (this.checkCanGenerate()) {
        Editor.Message.send("quickui", "startGenerate", {
          selectFile: selectFile,
          selectDirectory: selectDirectory,
          selectDirectoryCut: selectDirectory.replace(defaultDirPath + '\\', "")
        });
      }
    });
  },

  listeners: {},

  methods: {
    "onDialogEnd"(data) {
      if (data.paths && data.paths.length > 0) {
        if (data.type == "openFile") {
          selectFile = data.paths[0];
          console.log(selectFile);
          this.updatePaths();
        } else if (data.type == 'openDirectory') {
          selectDirectory = data.paths[0];
          console.log(selectDirectory);
          this.updatePaths();
        }
      }
    },

    'onChangeProgress'(data) {
      let progressVal = data.value * 100
      this.$.progressName.textContent = "进度: " + progressVal + "% " + data.name;
      this.$.progress.value = progressVal;
    },

    updatePaths() {
      this.$.selectPaths.value = "选择JSON: " + selectFile + "\n" + "选择目录: " + selectDirectory;
      let canGen = selectFile.length > 0 && selectDirectory.length > 0;
      this.$.btnGenerate.style.display = canGen ? "block" : "none";
    },

    checkCanGenerate() {
      let canGen = true;
      if (!selectDirectory.includes(defaultDirPath)) {
        canGen = false;
        console.log("目标目录不在resources中: " + selectDirectory);
        console.log("项目资源路径: " + defaultDirPath);
      }
      return canGen;
    },
  }
});