/*
 * @Author: edwin
 * @Date: 2024-04-12 18:58:25
 * @LastEditors: edwin
 * @LastEditTime: 2024-07-02 10:03:29
 */
const path = require('path');

var _root = null;
var _data = null;
var _event = null;
var _curNum = 0;
var _totalNum = 0;

exports.methods = {
    _exportPrefab() {
        if (cc.isValid(_root) && _data != null) {
            let imageDst = _data.dst;
            let dirName = path.basename(imageDst);
            // this._traverseNode(_root, "");
            let prefabPath = path.join(imageDst, dirName + ".prefab").replace(/\\/g, "/");
            this._savePrefab(prefabPath, _root);
            if (_event && _event.reply) {
                _event.reply(null, "执行完毕");
            }
            _root.destroy();
            _data = null;
            _event = null;
        }
    },
    
    _savePrefab(prefabPath, root) {
        let prefab = new cc.Prefab();
        prefab.data = root;
        prefab.nativeUrl = prefabPath;
        let str = EditorExtends.serialize(prefab);
        let dstDB = "db://" + prefabPath.replace(Editor.Project.path.replace(/\\/g, "/") + "/", "").replace(/\\/g, "/");
        Editor.Message.request('asset-db', 'create-asset', dstDB, str, {overwrite: true})
        .then((result) => {
            console.log("保存预制成功: " + result.path);
            Editor.Message.send("quickui", "onChangeProgress", {
                name: "保存预制成功: " + result.path,
                value: 1
            });
            prefab.destroy();
            prefab = null;
        }).catch((err) => {
            console.error(err);
            prefab.destroy();
            prefab = null;
        });;
    },

    _traverseNode(node, prefix) {
        if (cc.isValid(node)) {
            let sprite = node.getComponent(cc.Sprite);
            console.log(prefix + node.name + " sprite: " + (sprite != null ? sprite.name : "null"));
        }
        let childs = node.children;
        childs.forEach(subNode => {
            this._traverseNode(subNode, (prefix+"-"));
        });
    },

    _createSprite(node, spMap) {
        let imageObject = new cc.Node(node.name);
        imageObject.setPosition(node.x, node.y, imageObject.position.z);
        imageObject.addComponent("cc.UITransform");
        imageObject.getComponent("cc.UITransform").setContentSize(new cc.Size(node.width, node.height));

        if (spMap[node.name]) {
            cc.assetManager.loadAny(spMap[node.name].uuid, (err, spriteFrame) => {
                Editor.Message.send("quickui", "onChangeProgress", {
                    name: "加载Sprite: " + spMap[node.name].displayName + (err ? "失败": "成功") ,
                    value: 0.6
                });
                _curNum++;
                let isLast = _curNum >= _totalNum;
                if (err) {
                    console.error("加载精灵帧失败:", err);
                } else {
                    let sprite = imageObject.addComponent(cc.Sprite);
                    sprite.spriteFrame = spriteFrame;
                    console.log("设置图片为Sprite: " + spMap[node.name].url);
                }
                if (isLast) {
                    this._exportPrefab();
                }
            });
        } else {
            _curNum++;
            let isLast = _curNum >= _totalNum;
            if (isLast) {
                this._exportPrefab();
            }
        }

        Editor.Message.send("quickui", "onChangeProgress", {
            name: "加载Sprite: " + node.name,
            value: 0.5
        });
        return imageObject;
    },

    'generatePrefab': function (data) {
        let tree = data.tree
        let imageDst = data.dstCut;
        let dirname = path.basename(imageDst);
        let loadedMap = new Map();
        let spMap = data.spMap;
        _root = new cc.Node(dirname);
        _root.addComponent("cc.UITransform");
        _root.getComponent("cc.UITransform").setContentSize(new cc.Size(1280, 720));
        _data = data;
        _curNum = 0;
        _totalNum = tree.length;
        tree.forEach(node => {
            let parentId = node.parentId;
            let gameObject = this._createSprite(node, spMap);
            if (gameObject != null) {
                if (parentId >= 0 && loadedMap.get(parentId)) {
                    gameObject.setParent(loadedMap.get(parentId));
                    gameObject.setPosition(loadedMap.get(parentId).convertToNodeSpaceAR(gameObject.position)); // photoshop导出的坐标为世界坐标
                } else {
                    gameObject.setParent(_root);
                }
                if (!loadedMap.get(node.id)) {
                    loadedMap.set(node.id, gameObject);
                }
            }
        });
    }
};